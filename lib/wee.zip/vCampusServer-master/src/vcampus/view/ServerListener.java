package vcampus.view;

public interface ServerListener {
	public void LoginServerPerformed();
	public void LogoutServerPerformed();
}
