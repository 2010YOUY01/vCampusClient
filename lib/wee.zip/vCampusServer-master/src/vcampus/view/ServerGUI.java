package vcampus.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import vcampus.biz.MainServer;
import vcampus.biz.Server;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JScrollBar;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.Timer;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.SwingConstants;
import java.awt.Font;

public class ServerGUI extends JFrame {

	private JPanel contentPane;
	private JTextField textOnlineNum;
	private JTextField textPort;
	private Server server;
	private JTextArea textArea;
	private JButton btnLogin;
	private JButton btnLogout;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ServerGUI frame = new ServerGUI();
					Server server1 = new Server();
					server1.setServerGUI(frame);
					frame.setServer(server1);
					
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	/**
	 * Create the frame.
	 */
	
	public void createServer() {
		server = new Server();
		server.setServerGUI(this);
	}
	
	public ServerGUI () {
		setTitle("vCampus Server");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 692, 499);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lblCurrentTime = new JLabel("current time:");
		lblCurrentTime.setForeground(Color.WHITE);
		lblCurrentTime.setFont(new Font("Eras Light ITC", Font.PLAIN, 24));
		lblCurrentTime.setBounds(14, 93, 143, 30);
		
		JLabel lblOnlineNumber = new JLabel("online number:");
		lblOnlineNumber.setForeground(Color.WHITE);
		lblOnlineNumber.setFont(new Font("Eras Light ITC", Font.PLAIN, 24));
		lblOnlineNumber.setBounds(14, 154, 155, 30);
		
		JLabel lblListenPort = new JLabel("listen port:");
		lblListenPort.setForeground(Color.WHITE);
		lblListenPort.setFont(new Font("Eras Light ITC", Font.PLAIN, 24));
		lblListenPort.setBounds(14, 206, 129, 30);
		
		textOnlineNum = new JTextField();
		textOnlineNum.setBounds(188, 154, 135, 24);
		textOnlineNum.setEditable(false);
		textOnlineNum.setColumns(10);
		
		textPort = new JTextField();
		textPort.setBounds(188, 212, 135, 24);
		textPort.setEditable(false);
		textPort.setColumns(10);
		
		JLabel lblServerLog = new JLabel("Server Log");
		lblServerLog.setFont(new Font("Eras Light ITC", Font.PLAIN, 24));
		lblServerLog.setForeground(Color.WHITE);
		lblServerLog.setBounds(351, 13, 135, 28);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(837, 150, 371, 242);
		
		btnLogin = new JButton("");
		btnLogin.setBounds(96, 347, 197, 71);
		btnLogin.setIcon(new ImageIcon(ServerGUI.class.getResource("/material/\u5F00\u542F\u670D\u52A1\u5668.png")));
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// OK start the server
				// ceate a new Server
				createServer();
				// and start it as a thread
				new ServerRunning().start();
				btnLogin.setEnabled(false);
				btnLogout.setEnabled(true);
			}
		});
		
		
		
		//JLabel timeLabel = new JLabel("New label");
		ClockLabel timeLabel = new ClockLabel("time");
		timeLabel.setForeground(Color.WHITE);
		timeLabel.setFont(new Font("����ϸԲ��", Font.PLAIN, 24));
		timeLabel.setBounds(152, 96, 171, 24);
		
		btnLogout = new JButton("");
		btnLogout.setBounds(402, 345, 200, 73);
		btnLogout.setIcon(new ImageIcon(ServerGUI.class.getResource("/material/\u5173\u95ED\u670D\u52A1\u5668.png")));
		btnLogout.setEnabled(false);
		btnLogout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				server.stopServer();
				server = null;
				btnLogin.setEnabled(true);
				btnLogout.setEnabled(false);
				return;
			}
		});
		
		textArea = new JTextArea();
		textArea.setBounds(337, 43, 306, 242);
		contentPane.setLayout(null);
		contentPane.add(lblOnlineNumber);
		contentPane.add(lblListenPort);
		contentPane.add(lblCurrentTime);
		contentPane.add(textOnlineNum);
		contentPane.add(textPort);
		contentPane.add(timeLabel);
		contentPane.add(btnLogin);
		contentPane.add(btnLogout);
		contentPane.add(textArea);
		contentPane.add(scrollPane);
		contentPane.add(lblServerLog);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(ServerGUI.class.getResource("/material/\u540E\u53F0\u80CC\u666F.png")));
		lblNewLabel.setBounds(0, 0, 682, 320);
		contentPane.add(lblNewLabel);
	}
	


	public JTextField getTextOnlineNum() {
		return textOnlineNum;
	}



	public JTextField getTextPort() {
		return textPort;
	}

	public JTextArea getTextArea() {
		return textArea;
	}
	
	


	public void setServer(Server server) {
		this.server = server;
	}

	class ServerRunning extends Thread {
		public void run() {
			try {
				
				server.runServer();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}         // should execute until if fails
			// the server failed
			System.out.println("server failed");
			server = null;
		}
	}
}
