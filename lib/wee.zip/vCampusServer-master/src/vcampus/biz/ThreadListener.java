package vcampus.biz;

public interface ThreadListener {
	public void threadEnd(int id);
	public void displayLog(String log);
}
