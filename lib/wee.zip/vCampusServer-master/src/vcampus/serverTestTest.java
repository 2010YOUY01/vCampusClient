package vcampus;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class serverTestTest {

	@Test
	void test() {
		int a = 1;
		int b = 1;
		assertEquals(a,b);
	}

}
