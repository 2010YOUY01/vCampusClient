package vcampus.vo;

public class Product {
	private int uID;
	private String name;
	private double price;
	private String label;
}
