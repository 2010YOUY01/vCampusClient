package vcampus.vo;

import java.util.Date;

public class PersonInfo {
	private String username;//09017314
	private String name;//������
	private int age;//21
	public enum GENDER{
		MAlE, FEMALE, OTHER;
	}
	private GENDER gender;//MALE
	public enum SCHOOL{
		�����, ����, ��Ϣ, ����, ��ľ, ��ͨ, �Զ���;
	}
	private SCHOOL school;//�����
	//Date class useage:
	//Date brithday = new Date();
	//birthday.setYear(1998);birthday.setMonth(8);birthday.setDay(18);
	//birthday.getYear();.....
	private Date birthday; //1998 8 18
	private String City;// �����Ͼ�
	
	public static void main(String[] args) {
		Date date = new Date();
		date.setDate(21);
		date.setYear(1997);
		date.setMonth(8);
		System.out.println(date.getYear() + " " + date.getMonth() +" "+date.getDate());
		
	}

	public PersonInfo(String username, String name, int age, GENDER gender, SCHOOL school, Date birthday, String city) {
		super();
		this.username = username;
		this.name = name;
		this.age = age;
		this.gender = gender;
		this.school = school;
		this.birthday = birthday;
		City = city;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public GENDER getGender() {
		return gender;
	}

	public void setGender(GENDER gender) {
		this.gender = gender;
	}

	public SCHOOL getSchool() {
		return school;
	}

	public void setSchool(SCHOOL school) {
		this.school = school;
	}

	public Date getBirthday() {
		return birthday;
	}

	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}

	public String getCity() {
		return City;
	}

	public void setCity(String city) {
		City = city;
	}
	
	
}
