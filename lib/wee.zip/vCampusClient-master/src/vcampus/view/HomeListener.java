package vcampus.view;

public interface HomeListener {
	public void inHomePerfomed();
}
