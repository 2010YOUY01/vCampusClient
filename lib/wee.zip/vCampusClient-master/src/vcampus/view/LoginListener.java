package vcampus.view;

import vcampus.vo.LoginFormEvent;
import vcampus.vo.RegisterForm;

public interface LoginListener {
	public void LoginPerformed(LoginFormEvent event);
}
