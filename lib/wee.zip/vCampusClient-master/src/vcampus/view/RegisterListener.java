package vcampus.view;

import vcampus.vo.RegisterForm;

public interface RegisterListener {
	public void registerPerformed(RegisterForm registerForm);
}
