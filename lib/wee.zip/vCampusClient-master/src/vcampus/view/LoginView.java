package vcampus.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import vcampus.biz.RegisterController;
import vcampus.vo.LoginFormEvent;
import vcampus.vo.RegisterForm;
import vcampus.vo.User;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.Font;

public class LoginView extends JFrame{

	private JPanel contentPane;
	private JTextField usernameField;
	private LoginListener loginListener;
	private User user;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the frame.
	 */
	public LoginView(User user) {
		this.user = user;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 401, 401);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblUsername = new JLabel("");
		lblUsername.setIcon(new ImageIcon(LoginView.class.getResource("/material/user.png")));
		lblUsername.setBounds(40, 139, 48, 47);
		contentPane.add(lblUsername);
		
		JLabel lblPassword = new JLabel("");
		lblPassword.setIcon(new ImageIcon(LoginView.class.getResource("/material/password (1).png")));
		lblPassword.setBounds(40, 199, 48, 47);
		contentPane.add(lblPassword);
		
		usernameField = new JTextField();
		usernameField.setForeground(new Color(153,181,242));
		usernameField.setFont(new Font("Eras Light ITC", Font.PLAIN, 24));
		usernameField.setText("studentID:");
		usernameField.setBounds(116, 139, 211, 35);
		contentPane.add(usernameField);
		usernameField.setColumns(10);
		
		JButton btnLogin = new JButton("");
		btnLogin.setIcon(new ImageIcon(LoginView.class.getResource("/material/\u767B\u9646\u6309\u94AE.png")));
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String username = usernameField.getText();
				String password = new String(passwordField.getPassword());
				fireLoginEvent(new LoginFormEvent(username, password));
				
				//usernameField.setText("");
				passwordField.setText("");
		
			}
		});
		btnLogin.setBounds(181, 262, 146, 61);
		contentPane.add(btnLogin);
		
		/*JButton button = new JButton("\u6CE8\u518C");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RegisterView registerView = new RegisterView();
				RegisterController registerController = 
						new RegisterController(registerView, null);
				registerView.setRegisterListener(registerController);
				
				registerView.setVisible(true);
			}
		});
		button.setBounds(40, 284, 113, 27);
		contentPane.add(button);*/
		
		passwordField = new JPasswordField();
		passwordField.setForeground(new Color(153,181,242));
		passwordField.setFont(new Font("Eras Light ITC", Font.PLAIN, 24));
		passwordField.setBounds(116, 199, 211, 35);
		contentPane.add(passwordField);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setForeground(new Color(153,181,242));
		lblNewLabel.setIcon(new ImageIcon(LoginView.class.getResource("/material/\u767B\u9646\u5E95.png")));
		lblNewLabel.setBounds(0, 0, 383, 100);
		contentPane.add(lblNewLabel);
		
		class MouseAdp implements MouseListener{
			public MouseAdp(){}
			public void mouseClicked(MouseEvent e) {
			/**������¼�(�������º͵�����������)��������.**/
				RegisterView registerView = new RegisterView();
				RegisterController registerController = 
						new RegisterController(registerView, null);
				registerView.setRegisterListener(registerController);
				
				registerView.setVisible(true);
			}
			public void mouseEntered(MouseEvent e) {
			/**����Ƶ�����Ϸ���ʱ�¼���������.**/}
			public void mouseExited(MouseEvent e) {
			/**����ƿ����ʱ�¼���������.**/}
			public void mousePressed(MouseEvent e) {
			/**���������ϰ���(��û����)ʱ�¼���������.**/}
			public void mouseReleased(MouseEvent e) {
			/**���������ϵ����¼���������.**/}
			}
		JLabel lblNewLabel_1 = new JLabel("creat account");
		lblNewLabel_1.setForeground(new Color(153,181,242));
		lblNewLabel_1.setFont(new Font("Eras Light ITC", Font.BOLD, 20));
		lblNewLabel_1.setBounds(41, 281, 126, 29);
		lblNewLabel_1.addMouseListener(new MouseAdp());
		contentPane.add(lblNewLabel_1);
		
		setVisible(true);
	}

	public LoginListener getLoginListener() {
		return loginListener;
	}

	public void setLoginListener(LoginListener loginListener) {
		this.loginListener = loginListener;
	}
	
	public void fireLoginEvent(LoginFormEvent event) {
		if(loginListener != null) {
			loginListener.LoginPerformed(event);
		}
	}

	public JTextField getUsernameField() {
		return usernameField;
	}

	public void setUsernameField(JTextField usernameField) {
		this.usernameField = usernameField;
	}

	
	public JPasswordField getPasswordField() {
		return passwordField;
	}

	public void setPasswordField(JPasswordField passwordField) {
		this.passwordField = passwordField;
	}

	public void closeWindow() {
		setVisible(false);
	}
}
